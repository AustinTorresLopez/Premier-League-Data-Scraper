package com.postgresql.premierLeagueWebScraper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PremierLeagueWebScraperApplication {

	public static void main(String[] args) {
		SpringApplication.run(PremierLeagueWebScraperApplication.class, args);
	}

}
