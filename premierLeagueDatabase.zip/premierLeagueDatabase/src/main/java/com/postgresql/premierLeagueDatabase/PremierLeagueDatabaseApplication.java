package com.postgresql.premierLeagueDatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PremierLeagueDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PremierLeagueDatabaseApplication.class, args);
	}

}
